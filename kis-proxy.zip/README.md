# KIS Proxy (Vercel, Serverless)

한국투자증권 OpenAPI를 직접 브라우저에서 부를 수 없으니,
이 서버리스 API가 **안전하게 프록시**해 줍니다.

## 1) 배포
- 위 폴더 그대로 ZIP → Vercel 대시보드 **Deploy manually** 업로드
- 또는 GitHub에 올리고 Import

## 2) 환경변수 (Vercel → Project → Settings → Environment Variables)
- `KIS_APPKEY`     : KIS 발급 appkey
- `KIS_APPSECRET`  : KIS 발급 appsecret
- `KIS_IS_PAPER`   : `"true"`(기본) 또는 `"false"` (실전)

배포 후 **Redeploy** 또는 **환경변수 변경 시 재배포**.

## 3) 엔드포인트
- `GET /api/quote?code=005930`
- `GET /api/quotes?codes=005930,000660`
- `GET /api/health`

응답은 `{ ok: true, data: {...} }` 형태.  
주말/장마감에도 `prevClose`를 이용해 등락률이 보정되어 반환됩니다.

## 4) 주의
- KIS OpenAPI는 일일/분당 호출 제한이 있으니 과도한 병렬 호출을 피하세요.
- 이 API는 **시세 조회 전용** 예시입니다. 주문/체결은 별도 보안 요건이 있습니다.
