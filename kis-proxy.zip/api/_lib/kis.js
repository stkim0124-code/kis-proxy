// api/_lib/kis.js
// 한국투자증권 OpenAPI 프록시 공통 모듈 (Vercel Serverless)
//
// 필요한 환경변수(꼭 Vercel 프로젝트 Settings → Environment Variables에 등록):
// - KIS_APPKEY        (예: PSBXbKak3SMZtqeNewgNnnqtcFqZNBlN7gXm)
// - KIS_APPSECRET     (KIS 발급 appsecret)
// - KIS_IS_PAPER      ("true" | "false")  종목 시세: 모의투자/실전 선택
//
// ※ 엔드포인트/트랜잭션ID는 KIS 문서 버전에 따라 변경될 수 있어 변수로 빼 둡니다.

const APPKEY   = process.env.KIS_APPKEY  || "";
const APPSECRET= process.env.KIS_APPSECRET || "";
const IS_PAPER = (process.env.KIS_IS_PAPER || "true").toLowerCase() === "true";

// 엔드포인트 (문서 버전에 따라 조정)
const BASE = IS_PAPER
  ? "https://openapivts.koreainvestment.com:29443"  // 모의투자
  : "https://openapi.koreainvestment.com:9443";     // 실전

// OAuth 토큰 URL (v2 기준 tokenP)
const TOKEN_URL = `${BASE}/oauth2/tokenP`;

// 단일 현재가 조회 (국내 주식) TR ID
// v2 문서 예시: FHKST01010100 (정적호출, 현재가)
const TR_PRICE = "FHKST01010100";

// 간단 메모리 캐시 (서버리스 인스턴스 수명 내)
let _token = null;      // { access_token, expires_at }
const nowSec = () => Math.floor(Date.now() / 1000);

// 토큰 발급
async function fetchToken() {
  if (!APPKEY || !APPSECRET) throw new Error("KIS appkey/appsecret missing");
  // 캐시 유효하면 사용(만료 30초 전 재발급)
  if (_token && _token.expires_at - 30 > nowSec()) return _token.access_token;

  const body = {
    grant_type: "client_credentials",
    appkey: APPKEY,
    appsecret: APPSECRET
  };

  const r = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });

  if (!r.ok) {
    const t = await r.text().catch(() => "");
    throw new Error(`KIS token HTTP ${r.status} ${t}`);
  }
  const j = await r.json();
  // 응답 키는 문서/버전별로 다를 수 있어 일반적으로 access_token, expires_in 사용
  const access_token = j.access_token || j.accessToken || j.ACCESS_TOKEN;
  const expires_in   = Number(j.expires_in || 3500);
  if (!access_token) throw new Error(`KIS token parse fail: ${JSON.stringify(j)}`);

  _token = {
    access_token,
    expires_at: nowSec() + (isFinite(expires_in) ? expires_in : 3500)
  };
  return _token.access_token;
}

// 단일 종목 현재가
export async function getPriceOne(code6) {
  const token = await fetchToken();
  // J: 주식
  const url = new URL(`${BASE}/uapi/domestic-stock/v1/quotations/inquire-price`);
  url.searchParams.set("FID_COND_MRKT_DIV_CODE", "J");
  url.searchParams.set("FID_INPUT_ISCD", code6);

  const r = await fetch(url, {
    headers: {
      "authorization" : `Bearer ${token}`,
      "appkey"        : APPKEY,
      "appsecret"     : APPSECRET,
      "tr_id"         : TR_PRICE,
      "custtype"      : "P" // 개인
    }
  });

  if (!r.ok) {
    const t = await r.text().catch(() => "");
    throw new Error(`KIS price HTTP ${r.status} ${t}`);
  }
  const j = await r.json();

  // KIS 표준 응답에서 시세 필드 추출 (문서 기준 예시)
  // output: stck_prpr(현재가), prdy_vrss(전일대비), prdy_vrss_sign(1/2/3), prdy_ctrt(등락률), stck_prdy_clpr(전일종가) 등
  const o = j?.output || j?.output1 || {};
  const price   = toNum(o.stck_prpr);
  const prev    = toNum(o.stck_prdy_clpr);
  let   chgPct  = toNum(o.prdy_ctrt);

  // 등락률이 제공되지 않으면 계산
  if (chgPct == null && price != null && prev) chgPct = ((price / prev) - 1) * 100;

  return {
    code: code6,
    price,
    prevClose: prev ?? null,
    changePct: chgPct ?? null,
    ts: Date.now()
  };
}

// 여러 종목 (최대 20개 정도로 나눠 호출 권장)
export async function getPriceMany(codes) {
  const out = {};
  for (const c of codes) {
    try {
      out[c] = await getPriceOne(c);
      // 과도한 QPS 방지(서버리스 환경 보호)
      await sleep(60);
    } catch (e) {
      out[c] = { code: c, error: String(e.message || e) };
    }
  }
  return out;
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const toNum = (v) => {
  if (v === null || v === undefined) return null;
  const n = Number(String(v).replace(/[^\d.-]/g, ""));
  return isFinite(n) ? n : null;
};
