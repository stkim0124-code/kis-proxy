// api/health.js
export default async function handler(req, res) {
  res.setHeader("access-control-allow-origin", "*");
  res.status(200).json({ ok: true, env: {
    paper: (process.env.KIS_IS_PAPER || "true")
  }});
}
