// api/quote.js
import { getPriceOne } from "./_lib/kis.js";

export default async function handler(req, res) {
  // CORS & JSON
  res.setHeader("access-control-allow-origin", "*");
  res.setHeader("access-control-allow-methods", "GET,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type,authorization");
  if (req.method === "OPTIONS") return res.status(200).end();

  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const code = (url.searchParams.get("code") || "").replace(/\D/g, "").padStart(6, "0");
    if (!/^\d{6}$/.test(code)) return res.status(400).json({ error: "Invalid code (need 6 digits)" });

    const data = await getPriceOne(code);
    // 주말/장마감에도 prevClose로 등락률 보정되어 반환됩니다.
    res.setHeader("cache-control", "public, max-age=15, s-maxage=15");
    return res.status(200).json({ ok: true, data });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e.message || e) });
  }
}
