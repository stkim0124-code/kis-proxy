// api/quotes.js
import { getPriceMany } from "./_lib/kis.js";

export default async function handler(req, res) {
  res.setHeader("access-control-allow-origin", "*");
  res.setHeader("access-control-allow-methods", "GET,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type,authorization");
  if (req.method === "OPTIONS") return res.status(200).end();

  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const raw = url.searchParams.get("codes") || "";
    const codes = raw.split(",").map(s => s.replace(/\D/g,"").padStart(6,"0"))
      .filter(s => /^\d{6}$/.test(s)).slice(0, 40); // 안전상 40개 제한
    if (!codes.length) return res.status(400).json({ error: "codes=005930,000660,..." });

    const data = await getPriceMany(codes);
    res.setHeader("cache-control", "public, max-age=15, s-maxage=15");
    return res.status(200).json({ ok: true, data });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e.message || e) });
  }
}
